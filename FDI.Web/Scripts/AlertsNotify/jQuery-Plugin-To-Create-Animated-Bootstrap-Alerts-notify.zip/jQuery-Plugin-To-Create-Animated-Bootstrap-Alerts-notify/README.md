notify
======

Simple jquery plugin gives little bit animation to bootstrap alert. Forked from UIKit Notify add-on.

[http://egig.github.io/notify/](http://egig.github.io/notify/)
